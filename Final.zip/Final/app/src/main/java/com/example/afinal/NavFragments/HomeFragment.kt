package com.example.afinal.NavFragments

import androidx.fragment.app.Fragment
import com.example.afinal.R

class HomeFragment: Fragment(R.layout.fragment_home) {
}