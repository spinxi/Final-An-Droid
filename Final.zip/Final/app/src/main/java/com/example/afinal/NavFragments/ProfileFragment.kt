package com.example.afinal.NavFragments

import androidx.fragment.app.Fragment
import com.example.afinal.R

class ProfileFragment: Fragment(R.layout.fragment_profile) {
    
}